#include "kailash_uart.h"

void KailashUART::begin()
{
    UBRR0H = 0;
    UBRR0L = 103; // 9600 baud at 16MHz
    UCSR0B = (1 << TXEN0); // Enable transmitter
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // 8-bit data
}

void KailashUART::write(char data)
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void KailashUART::print(const char* str)
{
    while (*str)
    {
        write(*str++);
    }
}

KailashUART kailash;
