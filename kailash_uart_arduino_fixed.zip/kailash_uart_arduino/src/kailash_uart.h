#ifndef KAILASH_UART_H
#define KAILASH_UART_H

#include <avr/io.h>

class KailashUART {
public:
    void begin();
    void write(char data);
    void print(const char* str);
};

extern KailashUART kailash;

#endif
